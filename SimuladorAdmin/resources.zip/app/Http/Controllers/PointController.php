<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\RoomSetting;
use App\Models\RoomShooting;
use Illuminate\Http\Request;

class PointController extends Controller
{
    public  function index(){
        $rooms = Room::all();
        return view('historial.index', compact('rooms'));
    }
    public  function show($id){
        $room = Room::find($id);
        $room_shootings = RoomShooting::where('room_id', $id)->get();
        $point = array(
            'precision' => 0,
            'cabina' => 0,
            'batea' => 0,
            'cañon' => 0,
            'oruga' => 0,
            'reaccion' => 0
        );
        foreach ($room_shootings as $room_shooting){
            echo $point['precision'];
            $point["precision"] = $point["precision"] + (($room_shooting->site_shooting != -1) ? 1 : 0);
            $point["oruga"] = $point["oruga"] + (($room_shooting->site_shooting == 0) ? 1 : 0);
            $point["cañon"] = $point["cañon"] + (($room_shooting->site_shooting == 1) ? 1 : 0);
            $point["batea"] = $point["batea"] + (($room_shooting->site_shooting == 2) ? 1 : 0);
            $point["cabina"] = $point["cabina"] + (($room_shooting->site_shooting == 3) ? 1 : 0);
            $point["reaccion"] = $point["reaccion"] + $room_shooting->time;
        }
        $point["precision"] = ($point["precision"] / $room_shootings->count())*100;
        $point["oruga"] = ($point["oruga"] / $room_shootings->count())*100;
        $point["batea"] = ($point["batea"] / $room_shootings->count())*100;
        $point["cabina"] = ($point["cabina"] / $room_shootings->count())*100;
        $point["cañon"] = ($point["cañon"] / $room_shootings->count())*100;
        $point["reaccion"] = $point["reaccion"] / $room_shootings->count();
        $room_setting = RoomSetting::find($room->room_setting_id);
        //dd($point, $room_shootings);
        return view('historial.show', compact('room', 'room_setting', 'point', 'room_shootings'));
    }
}
