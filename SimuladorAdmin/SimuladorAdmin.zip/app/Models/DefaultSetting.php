<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DefaultSetting extends Model
{
    protected $fillable = ['name', 'room_setting_id'];
}
