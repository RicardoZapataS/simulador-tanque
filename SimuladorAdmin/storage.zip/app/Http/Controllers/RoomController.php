<?php

namespace App\Http\Controllers;

use App\Models\Room;
use App\Models\RoomSetting;
use App\Models\DefaultSetting;
use App\User;
use Illuminate\Http\Request;

class RoomController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $rooms = Room::all();
        return view('historial.index', compact('rooms'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Room  $room
     * @return \Illuminate\Http\Response
     */
    public function show($room)
    {
        $room = Room::find($room);
        $room_setting = RoomSetting::find($room->room_setting_id);
        $room_shootings = $room->room_shootings;
        //dd($room_shootings[0]->tar);
        $defaultSettings = DefaultSetting::where('room_setting_id', $room->room_setting_id)->get()->first()? DefaultSetting::where('room_setting_id', $room->room_setting_id)->get()->first()->name : "Personalizado";
        // dd($defaultSettings);
        $user = User::find($room->user_id);
        return view('historial.show', compact('room', 'room_setting', 'user', 'defaultSettings', 'room_shootings'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Room  $room
     * @return \Illuminate\Http\Response
     */
    public function edit(Room $room)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Room  $room
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Room $room)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Room  $room
     * @return \Illuminate\Http\Response
     */
    public function destroy(Room $room)
    {
        //
    }
}
